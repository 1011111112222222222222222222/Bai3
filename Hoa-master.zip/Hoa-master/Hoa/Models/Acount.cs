﻿using System;
using System.Collections.Generic;

namespace Hoa.Models;

public partial class Acount
{
    public int Acounid { get; set; }

    public string? Username { get; set; }

    public string? Pasword { get; set; }

    public virtual Cn Acoun { get; set; } = null!;

    public virtual News? News { get; set; }
}
