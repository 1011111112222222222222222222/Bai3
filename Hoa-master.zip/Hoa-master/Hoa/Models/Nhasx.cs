﻿using System;
using System.Collections.Generic;

namespace Hoa.Models;

public partial class Nhasx
{
    public int Mansx { get; set; }

    public string? Tennsx { get; set; }

    public DateTime? Ngaytl { get; set; }

    public virtual Product Mansx1 { get; set; } = null!;

    public virtual Cn MansxNavigation { get; set; } = null!;
}
