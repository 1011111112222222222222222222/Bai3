﻿using System;
using System.Collections.Generic;

namespace Hoa.Models;

public partial class ProductDetail
{
    public int Detailid { get; set; }

    public string? Namedetail { get; set; }

    public virtual Product Detail { get; set; } = null!;
}
