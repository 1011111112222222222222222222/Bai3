﻿using System;
using System.Collections.Generic;

namespace Hoa.Models;

public partial class News
{
    public int Idnews { get; set; }

    public string? Newwork { get; set; }

    public virtual Acount IdnewsNavigation { get; set; } = null!;
}
