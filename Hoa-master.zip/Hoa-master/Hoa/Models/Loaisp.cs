﻿using System;
using System.Collections.Generic;

namespace Hoa.Models;

public partial class Loaisp
{
    public int Malsp { get; set; }

    public string? Tenlsp { get; set; }

    public virtual Product MalspNavigation { get; set; } = null!;
}
