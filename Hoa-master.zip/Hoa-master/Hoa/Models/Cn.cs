﻿using System;
using System.Collections.Generic;

namespace Hoa.Models;

public partial class Cn
{
    public int Macn { get; set; }

    public string? Tencn { get; set; }

    public string? Diachi { get; set; }

    public int? Masp { get; set; }

    public virtual Acount? Acount { get; set; }

    public virtual Nhasx? Nhasx { get; set; }
}
