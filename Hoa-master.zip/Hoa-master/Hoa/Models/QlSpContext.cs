﻿using System;
using System.Collections.Generic;
using Microsoft.EntityFrameworkCore;

namespace Hoa.Models;

public partial class QlSpContext : DbContext
{
    public QlSpContext()
    {
    }

    public QlSpContext(DbContextOptions<QlSpContext> options)
        : base(options)
    {
    }

    public virtual DbSet<Acount> Acounts { get; set; }

    public virtual DbSet<Cn> Cns { get; set; }

    public virtual DbSet<Invoice> Invoices { get; set; }

    public virtual DbSet<Loaisp> Loaisps { get; set; }

    public virtual DbSet<News> News { get; set; }

    public virtual DbSet<Nhasx> Nhasxes { get; set; }

    public virtual DbSet<Product> Products { get; set; }

    public virtual DbSet<ProductDetail> ProductDetails { get; set; }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. You can avoid scaffolding the connection string by using the Name= syntax to read it from configuration - see https://go.microsoft.com/fwlink/?linkid=2131148. For more guidance on storing connection strings, see http://go.microsoft.com/fwlink/?LinkId=723263.
        => optionsBuilder.UseSqlServer("Data Source=ADMIN-PC\\SQLEXPRESS01;Initial Catalog=QL_SP;Integrated Security=True;Connect Timeout=30;Encrypt=False;Trust Server Certificate=False;Application Intent=ReadWrite;Multi Subnet Failover=False");

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        modelBuilder.Entity<Acount>(entity =>
        {
            entity.HasKey(e => e.Acounid).HasName("PK__ACOUNT__7556C41E69A660DE");

            entity.ToTable("ACOUNT");

            entity.Property(e => e.Acounid)
                .ValueGeneratedOnAdd()
                .HasColumnName("ACOUNID");
            entity.Property(e => e.Pasword)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("PASWORD");
            entity.Property(e => e.Username)
                .HasMaxLength(50)
                .IsUnicode(false)
                .IsFixedLength()
                .HasColumnName("USERNAME");

            entity.HasOne(d => d.Acoun).WithOne(p => p.Acount)
                .HasForeignKey<Acount>(d => d.Acounid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_AC");
        });

        modelBuilder.Entity<Cn>(entity =>
        {
            entity.HasKey(e => e.Macn).HasName("PK__CN__603F183C6F0D0B92");

            entity.ToTable("CN");

            entity.Property(e => e.Macn).HasColumnName("MACN");
            entity.Property(e => e.Diachi)
                .HasMaxLength(40)
                .HasColumnName("DIACHI");
            entity.Property(e => e.Masp).HasColumnName("MASP");
            entity.Property(e => e.Tencn)
                .HasMaxLength(40)
                .HasColumnName("TENCN");
        });

        modelBuilder.Entity<Invoice>(entity =>
        {
            entity.HasKey(e => e.Id).HasName("PK__INVOICE__3214EC2741CFE409");

            entity.ToTable("INVOICE");

            entity.Property(e => e.Id)
                .ValueGeneratedOnAdd()
                .HasColumnName("ID");
            entity.Property(e => e.Nameiv)
                .HasMaxLength(40)
                .HasColumnName("NAMEIV");
            entity.Property(e => e.Price)
                .HasColumnType("money")
                .HasColumnName("PRICE");
            entity.Property(e => e.Quantity).HasColumnName("QUANTITY");

            entity.HasOne(d => d.IdNavigation).WithOne(p => p.Invoice)
                .HasForeignKey<Invoice>(d => d.Id)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__INVOICE__ID__2BFE89A6");
        });

        modelBuilder.Entity<Loaisp>(entity =>
        {
            entity.HasKey(e => e.Malsp).HasName("PK__LOAISP__7A3DC3946D01715A");

            entity.ToTable("LOAISP");

            entity.Property(e => e.Malsp)
                .ValueGeneratedOnAdd()
                .HasColumnName("MALSP");
            entity.Property(e => e.Tenlsp)
                .HasMaxLength(40)
                .HasColumnName("TENLSP");

            entity.HasOne(d => d.MalspNavigation).WithOne(p => p.Loaisp)
                .HasForeignKey<Loaisp>(d => d.Malsp)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK");
        });

        modelBuilder.Entity<News>(entity =>
        {
            entity.HasKey(e => e.Idnews).HasName("PK__NEWS__3FFED9CA82209E08");

            entity.ToTable("NEWS");

            entity.Property(e => e.Idnews)
                .ValueGeneratedOnAdd()
                .HasColumnName("IDNEWS");
            entity.Property(e => e.Newwork).HasColumnName("NEWWORK");

            entity.HasOne(d => d.IdnewsNavigation).WithOne(p => p.News)
                .HasForeignKey<News>(d => d.Idnews)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__NEWS__IDNEWS__756D6ECB");
        });

        modelBuilder.Entity<Nhasx>(entity =>
        {
            entity.HasKey(e => e.Mansx).HasName("PK__NHASX__7ABD278DC64FD1AB");

            entity.ToTable("NHASX");

            entity.Property(e => e.Mansx)
                .ValueGeneratedOnAdd()
                .HasColumnName("MANSX");
            entity.Property(e => e.Ngaytl)
                .HasColumnType("datetime")
                .HasColumnName("NGAYTL");
            entity.Property(e => e.Tennsx)
                .HasMaxLength(40)
                .HasColumnName("TENNSX");

            entity.HasOne(d => d.MansxNavigation).WithOne(p => p.Nhasx)
                .HasForeignKey<Nhasx>(d => d.Mansx)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SX_01");

            entity.HasOne(d => d.Mansx1).WithOne(p => p.Nhasx)
                .HasForeignKey<Nhasx>(d => d.Mansx)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK_SX");
        });

        modelBuilder.Entity<Product>(entity =>
        {
            entity.HasKey(e => e.Masp).HasName("PK__SP__60228A3229937CB0");

            entity.ToTable("PRODUCT");

            entity.Property(e => e.Masp).HasColumnName("MASP");
            entity.Property(e => e.Gia)
                .HasColumnType("money")
                .HasColumnName("GIA");
            entity.Property(e => e.Hinh)
                .HasMaxLength(50)
                .IsUnicode(false)
                .HasColumnName("HINH");
            entity.Property(e => e.Soluong).HasColumnName("SOLUONG");
            entity.Property(e => e.Tensp)
                .HasMaxLength(40)
                .HasColumnName("TENSP");
        });

        modelBuilder.Entity<ProductDetail>(entity =>
        {
            entity.HasKey(e => e.Detailid).HasName("PK__PRODUCT___0E176F9ADAE88D23");

            entity.ToTable("PRODUCT_DETAIL");

            entity.Property(e => e.Detailid)
                .ValueGeneratedOnAdd()
                .HasColumnName("DETAILID");
            entity.Property(e => e.Namedetail).HasColumnName("NAMEDETAIL");

            entity.HasOne(d => d.Detail).WithOne(p => p.ProductDetail)
                .HasForeignKey<ProductDetail>(d => d.Detailid)
                .OnDelete(DeleteBehavior.ClientSetNull)
                .HasConstraintName("FK__PRODUCT_D__DETAI__0880433F");
        });

        OnModelCreatingPartial(modelBuilder);
    }

    partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
}
