﻿namespace Hoa.Models
{
	public class CartItem
	{
		public int Mahh { get; set; }
		//public int MaHh { get; internal set; }
		public string  Tenhh { get; set; }

		public string Hinh  { get; set; }

		public double Dongia { get; set; }

		public int SoLuong { get; set; }
		public double ThanhTien => SoLuong * Dongia;
	}
}
