﻿using System;
using System.Collections.Generic;

namespace Hoa.Models;

public partial class Product
{
    public int Masp { get; set; }

    public string? Tensp { get; set; }

    public int? Soluong { get; set; }

    public decimal? Gia { get; set; }

    public string? Hinh { get; set; }

    public virtual Invoice? Invoice { get; set; }

    public virtual Loaisp? Loaisp { get; set; }

    public virtual Nhasx? Nhasx { get; set; }

    public virtual ProductDetail? ProductDetail { get; set; }
}
